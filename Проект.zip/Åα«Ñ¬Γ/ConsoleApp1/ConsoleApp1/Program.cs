﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            double s = 0;
            Console.WriteLine("MathLen - Solving systems of linear equations.\n");
            Console.WriteLine("Работу выполнила студент группы ИСП211 Юсупова Анастасия\n");
            Console.Write("\n");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Для просмотра инструкции по эксплуатации нажмите F1\n");
            Console.ResetColor();
            if (Console.ReadKey().Key == ConsoleKey.F1)
            {
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                Console.WriteLine("Инструкция\n");
                Console.WriteLine("Решение систем линейных уравнений\n 1.Вводите данные построчно после каждого заголовка.");
                Console.WriteLine("Пример\n \nВведите построчно коэффициенты системы\n(заполните все 4 строки, чтобы программа проверила, точно ли это число)\n-1\n\n-1\n-1");
                Console.WriteLine("2.Нельзя оставлять ячейку без данных.\n В данном случае программа не сможет работать.");
                Console.WriteLine("3.Для конечного ответа нажимайте Enter, чтобы программа дала полный ответ.");
                Console.WriteLine("4.Вводите только цифры.");
                Console.WriteLine("5.Наслаждайтесть программой.");
                Console.Write("\n");
                Console.Write("\n");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Введите размерность системы");
                Console.ResetColor();
                string result = "";
                try
                {
                    int a = Convert.ToInt32(Console.ReadLine()); //вводим данные, и конвертируем в целое число
                }
                catch (FormatException)
                {
                    result = "Ошибка. Вы ввели не число(пропустите строку и начните заново)";
                }
                Console.WriteLine(result);
                Console.ReadLine();
                //int n = int.Parse(Console.ReadLine());
                int n;
                string str = Console.ReadLine();
                //string s1 = n.ToString();
                if (str == "")
                {
                    Console.WriteLine("Error");
                    Console.ReadKey();
                }
                else
                {
                    n = Int32.Parse(str);
                    double[,] a = new double[n, n];
                    double[] b = new double[n];
                    double[] x = new double[n];
                    for (int i = 0; i < n; i++)
                        x[i] = 0;
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("Введите построчно коэффициенты системы");
                    Console.ResetColor();
                    string result1 = "";
                    try
                    {
                        int m = Convert.ToInt32(Console.ReadLine()); //вводим данные, и конвертируем в целое число
                    }
                    catch (FormatException)
                    {
                        result1 = "Ошибка. Вы ввели не число(пропустите строку и начните заново)";
                    }
                    Console.WriteLine(result1);
                    Console.ReadLine();
                    for (int i = 0; i < n; i++)
                        for (int j = 0; j < n; j++)
                        {
                            a[i, j] = double.Parse(Console.ReadLine());
                        }
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("Введите свободные коэффициенты");
                    Console.ResetColor();
                    string result2 = "";
                    try
                    {
                        int m = Convert.ToInt32(Console.ReadLine()); //вводим данные, и конвертируем в целое число
                    }
                    catch (FormatException)
                    {
                        result2 = "Ошибка. Вы ввели не число(пропустите строку и начните заново)";
                    }
                    Console.WriteLine(result2);
                    Console.ReadLine();
                    for (int i = 0; i < n; i++)
                        b[i] = double.Parse(Console.ReadLine());

                    for (int k = 0; k < n - 1; k++)
                    {
                        for (int i = k + 1; i < n; i++)
                        {
                            for (int j = k + 1; j < n; j++)
                            {
                                a[i, j] = a[i, j] - a[k, j] * (a[i, k] / a[k, k]);
                            }
                            b[i] = b[i] - b[k] * a[i, k] / a[k, k];
                        }

                    }
                    for (int k = n - 1; k >= 0; k--)
                    {
                        s = 0;
                        for (int j = k + 1; j < n; j++)
                            s = s + a[k, j] * x[j];
                        x[k] = (b[k] - s) / a[k, k];
                    }
                    for (int i = 0; i < x.Length; i++)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Система имеет следующие корни");
                        Console.ResetColor();
                        Console.WriteLine("x = {0:0.##}", x[i]);
                        Console.WriteLine("y = {0:0.##}", x[i]);
                        Console.WriteLine("z = {0:0.##}", x[i]);
                        Console.ReadKey();
                    }
                }
                Console.ReadKey();
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Введите размерность системы");
                Console.ResetColor();
                string result1 = "";
                try
                {
                    int m = Convert.ToInt32(Console.ReadLine()); //вводим данные, и конвертируем в целое число
                }
                catch (FormatException)
                {
                    result1 = "Ошибка. Вы ввели не число(пропустите строку и начните заново)";
                }
                Console.WriteLine(result1);
                Console.ReadLine();
                //int n = int.Parse(Console.ReadLine());
                int n;
                string str = Console.ReadLine();
                //string s1 = n.ToString();
                if (str == "")
                {
                    Console.WriteLine("Error");
                    Console.ReadKey();
                }
                else
                {
                    n = Int32.Parse(str);
                    double[,] a = new double[n, n];
                    double[] b = new double[n];
                    double[] x = new double[n];
                    for (int i = 0; i < n; i++)
                        x[i] = 0;
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("Введите построчно коэффициенты системы");
                    Console.ResetColor();
                    string result2 = "";
                    try
                    {
                        int m = Convert.ToInt32(Console.ReadLine()); //вводим данные, и конвертируем в целое число
                    }
                    catch (FormatException)
                    {
                        result2 = "Ошибка. Вы ввели не число(пропустите строку и начните заново)";
                    }
                    Console.WriteLine(result2);
                    Console.ReadLine();
                    for (int i = 0; i < n; i++)
                        for (int j = 0; j < n; j++)
                        {
                            a[i, j] = double.Parse(Console.ReadLine());
                        }
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("Введите свободные коэффициенты");
                    Console.ResetColor();
                    string result = "";
                    try
                    {
                        int m = Convert.ToInt32(Console.ReadLine()); //вводим данные, и конвертируем в целое число
                    }
                    catch (FormatException)
                    {
                        result = "Ошибка. Вы ввели не число(пропустите строку и начните заново)";
                    }
                    Console.WriteLine(result);
                    Console.ReadLine();
                    for (int i = 0; i < n; i++)
                        b[i] = double.Parse(Console.ReadLine());

                    for (int k = 0; k < n - 1; k++)
                    {
                        for (int i = k + 1; i < n; i++)
                        {
                            for (int j = k + 1; j < n; j++)
                            {
                                a[i, j] = a[i, j] - a[k, j] * (a[i, k] / a[k, k]);
                            }
                            b[i] = b[i] - b[k] * a[i, k] / a[k, k];
                        }

                    }
                    for (int k = n - 1; k >= 0; k--)
                    {
                        s = 0;
                        for (int j = k + 1; j < n; j++)
                            s = s + a[k, j] * x[j];
                        x[k] = (b[k] - s) / a[k, k];
                    }
                    for (int i = 0; i < x.Length; i++)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Система имеет следующие корни");
                        Console.ResetColor();
                        Console.WriteLine("x = {0:0.##}", x[i]);
                        Console.WriteLine("y = {0:0.##}", x[i]);
                        Console.WriteLine("z = {0:0.##}", x[i]);
                        Console.ReadKey();
                    }
                }
            }
        }
    }
}
