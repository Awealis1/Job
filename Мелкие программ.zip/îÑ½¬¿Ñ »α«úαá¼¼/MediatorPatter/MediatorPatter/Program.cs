﻿using System;

namespace MediatorPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Лабораторную работу выполнил студент группы ИСП411 Юсупова Анастасия");

            Component1 component1 = new Component1();
            Component2 component2 = new Component2();
            Mediator mediator = new Mediator(component1, component2);

            mediator.Notify();

            Console.ReadKey();
        }
    }

    public interface IMediator
    {
        void Notify();
    }

    class Mediator : IMediator
    {
        private Component1 _component1;

        private Component2 _component2;

        public Mediator(Component1 component1, Component2 component2)
        {
            this._component1 = component1;
            this._component1.SetMediator(this);

            this._component2 = component2;
            this._component2.SetMediator(this);
        }

        public void Notify()
        {
            Console.WriteLine("Введите метод: ");
            string command = Console.ReadLine();

            switch (command)
            {
                case "1":
                    this._component1.FindSum();
                    break;

                case "2":
                    this._component1.FindAVG();
                    break;

                case "3":
                    this._component2.FindMax();
                    break;

                case "4":
                    this._component2.FindMin();
                    break;

                default:
                    this.Notify();
                    break;
            }
        }
    }

    class BaseComponent
    {
        protected IMediator _mediator;

        public BaseComponent(IMediator mediator = null) => this._mediator = mediator;

        public void SetMediator(IMediator mediator) => this._mediator = mediator;
    }

    class Component1 : BaseComponent
    {
        public void FindSum()
        {
            Random random = new Random();
            int value1 = random.Next(0, 10);
            int value2 = random.Next(0, 10);

            Console.WriteLine($"Первое рандомное число: {value1}");
            Console.WriteLine($"Второе рандомное число: {value2}");

            Console.WriteLine($"Сумма чисел: {value1 + value2}");

            this._mediator.Notify();
        }

        public void FindAVG()
        {
            Random random = new Random();
            int value1 = random.Next(0, 10);
            int value2 = random.Next(0, 10);

            Console.WriteLine($"Первое рандомное число: {value1}");
            Console.WriteLine($"Второе рандомное число: {value2}");

            Console.WriteLine($"Среднее значение: {value1 + value2 / 2}");

            this._mediator.Notify();
        }
    }

    class Component2 : BaseComponent
    {
        public void FindMax()
        {
            Random random = new Random();
            int value1 = random.Next(0, 10);
            int value2 = random.Next(0, 10);

            Console.WriteLine($"Первое рандомное число: {value1}");
            Console.WriteLine($"Второе рандомное число: {value2}");

            int max = value1 > value2 ? value1 : value2;

            Console.WriteLine($"Максимальное значение среди чисел: {max}");

            this._mediator.Notify();
        }

        public void FindMin()
        {
            Random random = new Random();
            int value1 = random.Next(0, 10);
            int value2 = random.Next(0, 10);

            Console.WriteLine($"Первое рандомное число: {value1}");
            Console.WriteLine($"Второе рандомное число: {value2}");

            int min = value1 < value2 ? value1 : value2;

            Console.WriteLine($"Минимальное значение среди чисел: {min}");

            this._mediator.Notify();
        }
    }
}