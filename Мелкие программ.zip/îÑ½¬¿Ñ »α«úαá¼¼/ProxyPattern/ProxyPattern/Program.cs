﻿using System;

namespace ProxyPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Лабораторная работа выполнена студентом ИСП411 Юсуповой Анастасией");

            Subject subject = new Proxy();
            Subject subject1 = new RealSubject();

            Console.WriteLine("Главная программа вызывает реальный объект:");
            subject1.Request();

            Console.WriteLine("Главная программы вызывает реальный объект и Proxy объект:");
            subject.Request();

            Console.Read();
        }
    }

    abstract class Subject
    {
        public abstract void Request();
    }

    class RealSubject : Subject
    {
        public override void Request()
        {
            Console.WriteLine("Вызван реальный объект");
        }
    }
    class Proxy : Subject
    {
        RealSubject realSubject;
        public override void Request()
        {
            realSubject = new RealSubject();
            realSubject.Request();
            Console.WriteLine("Вызван заместитель");
        }
    }
}
