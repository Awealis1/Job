﻿using System;

namespace StrategyPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Лабораторную работу выполнил студент ИСП411 Юсупова Анастасия");

            Console.WriteLine("Введите 2 целых числа");
            int num1 = Int32.Parse(Console.ReadLine());
            int num2 = Int32.Parse(Console.ReadLine());

            Context context = new Context(new SumNums(), num1, num2);

            Console.WriteLine("Стратегия 1 сумма " + context.ExecuteAlgorithm());

            context.ContextStrategy = new MultiplyNums();
            Console.WriteLine("Стратегия 2 умножение " + context.ExecuteAlgorithm());

            context.ContextStrategy = new OnePowTwo();
            Console.WriteLine("Стратегия 3 степень " + context.ExecuteAlgorithm());

            Console.Read();
        }
    }

    public interface IStrategy
    {
        public int DoStrategy(int num1, int num2);
    }

    public class SumNums : IStrategy
    {
        public int DoStrategy(int num1, int num2) => num1 + num2;
    }

    public class MultiplyNums : IStrategy
    {
        public int DoStrategy(int num1, int num2) => num1 * num2;
    }

    public class OnePowTwo : IStrategy
    {
        public int DoStrategy(int num1, int num2) => (int)Math.Pow(num1, num2);
    }

    public class Context
    {
        public IStrategy ContextStrategy { get; set; }
        int num1, num2;

        public Context(IStrategy _strategy, int num1, int num2)
        {
            ContextStrategy = _strategy;
            this.num1 = num1;
            this.num2 = num2;
        }

        public int ExecuteAlgorithm()
        {
            return ContextStrategy.DoStrategy(num1, num2);
        }
    }

}
