﻿using System;

namespace StatePattern
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Лабораторная работа сделана студентом группы ИСП411 Юсуповой Анастасией");


            StateMachine stateMachine = new StateMachine(new SolidState());

            stateMachine.Cool();
            stateMachine.Cool();
            stateMachine.Cool();
            stateMachine.Heat();
            stateMachine.Cool();
            stateMachine.Heat();
            stateMachine.Heat();

            Console.Read();
        }
    }

    class StateMachine
    {
        public IAmmiacState State { get; set; }

        public StateMachine(IAmmiacState state)
        {
            this.State = state;
        }

        public void Heat()
        {
            State.Heat(this);
        }
        public void Cool()
        {
            State.Cool(this);
        }
    }

    interface IAmmiacState
    {
        void Heat(StateMachine water);
        void Cool(StateMachine water);
    }

    class SolidState : IAmmiacState
    {
        public void Heat(StateMachine ammiac)
        {
            Console.WriteLine("Превращаем лед в жидкость");
            ammiac.State = new LiquidState();
        }

        public void Cool(StateMachine water)
        {
            Console.WriteLine("Продолжаем заморозку льда");
        }
    }
    class LiquidState : IAmmiacState
    {
        public void Heat(StateMachine water)
        {
            Console.WriteLine("Превращаем жидкость в пар");
            water.State = new GasState();
        }

        public void Cool(StateMachine water)
        {
            Console.WriteLine("Превращаем жидкость в лед");
            water.State = new SolidState();
        }
    }
    class GasState : IAmmiacState
    {
        public void Heat(StateMachine water)
        {
            Console.WriteLine("Нагреваем газ");
        }

        public void Cool(StateMachine water)
        {
            Console.WriteLine("Охлаждаем пар в жидкость");
            water.State = new LiquidState();
        }
    }
}
