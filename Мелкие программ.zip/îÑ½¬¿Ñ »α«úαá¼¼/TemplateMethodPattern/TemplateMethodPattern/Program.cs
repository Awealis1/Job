﻿using System;
using System.Collections.Generic;

namespace TemplateMethodPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Лабораторная работа выполнена студентом группы ИСП411 Юсуповой Анастасией");

            string str = "Паттерн - Шаблонный метод предлагает разбить алгоритм на последовательность шагов, " +
                "описать эти шаги в отдельных методах и вызывать их в одном шаблонном методе друг за другом";

            ConcreteClass concrete = new ConcreteClass(str);

            concrete.TemplateMethod();

            Console.Read();
        }
    }

    abstract class AbstractClass
    {
        public string str;
        public AbstractClass(string str) => this.str = str;

        public void TemplateMethod()
        {
            this.BaseOperation1();
            this.RequiredOperations1();
            this.RequiredOperation2();
            this.RequiredOperation3();
            this.BaseOperation2();
        }

        // Эти операции уже имеют реализации.
        protected void BaseOperation1()
        {
            Console.WriteLine("Пусто");
        }

        protected void BaseOperation2()
        {
            Console.WriteLine("Конец программы");
        }

        protected abstract void RequiredOperations1();
        protected abstract void RequiredOperation2();
        protected abstract void RequiredOperation3();
    }

    class ConcreteClass : AbstractClass
    {
        public ConcreteClass(string str) : base(str)
        {

        }

        protected override void RequiredOperations1()
        {
            string result = "";

            for (int i = str.Length - 1; i >= 0; i--)
            {
                result += str[i];
            }

            Console.WriteLine(result);
        }

        protected override void RequiredOperation2()
        {
            List<char> vowels = new List<char>("аеёиоуыэюя");

            string result = "";
            char temp;

            foreach (var chars in str)
            {
                temp = vowels.Contains(chars) ? '*' : chars;

                result += temp;
            }

            Console.WriteLine(result);
        }

        protected override void RequiredOperation3()
        {
            List<char> vowels = new List<char>("вд");

            string result = "";
            char temp;

            foreach (var chars in str)
            {
                temp = vowels.Contains(chars) ? '_' : chars;

                result += temp;
            }

            Console.WriteLine(result);
        }
    }
}
