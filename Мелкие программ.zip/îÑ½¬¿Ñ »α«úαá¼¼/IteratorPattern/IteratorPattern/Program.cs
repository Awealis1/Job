﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace IteratorPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Лабораторная работа выполнена студентом группы ИСП411 Юсупова Анастасия");

            var collection = new WordsCollection();
            collection.AddItem("Зов Ктулху");
            collection.AddItem("Ромео и Джульета");
            collection.AddItem("Оазиз");
            collection.AddItem("Гамлет");
            collection.AddItem("Война и Мир");
            collection.AddItem("Продавец воздуха");

            Console.WriteLine(" Все книги в порядке заполнения:");

            foreach (var element in collection)
                Console.WriteLine(element);

            Console.WriteLine("\nВ алфавитном порядке:");

            collection.ReverseDirection1();

            foreach (var element in collection)
                Console.WriteLine(element);

            Console.WriteLine("\nВ обратном алфавитном порядке:");

            collection.ReverseDirection2();

            foreach (var element in collection)
                Console.WriteLine(element);

            Console.ReadKey();
        }
    }

    abstract class Iterator : IEnumerator
    {
        object IEnumerator.Current => Current();

        public abstract int Key();

        public abstract object Current();

        public abstract bool MoveNext();

        public abstract void Reset();
    }

    abstract class IteratorAggregate : IEnumerable
    {
        public abstract IEnumerator GetEnumerator();
    }

    class AlphabeticalOrderIterator : Iterator
    {
        private WordsCollection _collection;

        private int _position = -1;

        private bool _reverse = false;

        public AlphabeticalOrderIterator(WordsCollection collection, bool reverse = false)
        {
            this._collection = collection;
            this._reverse = reverse;

            if (reverse)
                this._position = collection.GetItems().Count;
        }

        public override object Current() => this._collection.GetItems()[_position];

        public override int Key() => this._position;

        public override bool MoveNext()
        {
            int updatedPosition = this._position + (this._reverse ? -1 : 1);

            if (updatedPosition >= 0 && updatedPosition < this._collection.GetItems().Count)
            {
                this._position = updatedPosition;
                return true;
            }
            else
                return false;
        }

        public override void Reset() => this._position = this._reverse ? this._collection.GetItems().Count - 1 : 0;
    }

    class WordsCollection : IteratorAggregate
    {
        List<string> _collection = new List<string>();

        bool _direction = false;

        public void ReverseDirection() => _direction = !_direction;
        public void ReverseDirection1() => _collection = _collection.OrderBy(x => x).ToList();
        public void ReverseDirection2() => _collection = _collection.OrderByDescending(x => x).ToList();

        public List<string> GetItems() => _collection;

        public void AddItem(string item) => this._collection.Add(item);

        public override IEnumerator GetEnumerator() => new AlphabeticalOrderIterator(this, _direction);
    }
}