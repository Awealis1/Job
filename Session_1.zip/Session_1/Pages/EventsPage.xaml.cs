﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Session_1.Pages
{
    /// <summary>
    /// Логика взаимодействия для EventsPage.xaml
    /// </summary>
    public partial class EventsPage : Page
    {
        public EventsPage()
        {
            InitializeComponent();

            try
            {
                EventsGrid.ItemsSource = ModelAccess.Context.Activities.ToList();
            }
            catch (Exception)
            {
                MessageBox.Show("Что-то пошло не так");
            }
        }

        private void DescBT_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                EventsGrid.ItemsSource = ModelAccess.Context.Activities.OrderBy(x => x.Events.Date).ToList();
            }
            catch (Exception)
            {
                MessageBox.Show("Что-то пошло не так");
            }

        }

        private void AscBT_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                EventsGrid.ItemsSource = ModelAccess.Context.Activities.OrderByDescending(x => x.Events.Date).ToList();
            }
            catch (Exception)
            {
                MessageBox.Show("Что-то пошло не так");
            }
        }

        private void BackBT_Click(object sender, RoutedEventArgs e)
        {
            if (Manager.MainFrame.CanGoBack)
            {
                Manager.MainFrame.GoBack();
            }
        }
    }
}
