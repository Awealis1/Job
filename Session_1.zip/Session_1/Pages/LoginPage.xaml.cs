﻿using Session_1.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Session_1.Pages
{
    /// <summary>
    /// Логика взаимодействия для LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Page
    {
        public LoginPage()
        {
            InitializeComponent();

            LoginTB.Focus();
        }

        private void LoginBT_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Users user = ModelAccess.Context.Users.Where(x => x.ID.ToString() == LoginTB.Text & x.Password == PasswordTB.Password).FirstOrDefault();

                if (user != null)
                {
                    ModelAccess.CurrentUser = user;

                    MessageBox.Show("Успешный вход!");

                    switch (user.Roles.Role)
                    {
                        case "Организатор":
                            Manager.MainFrame.Navigate(new Pages.ManagerPage());
                            break;

                        default:
                            break;
                    }
                }
                else
                {
                    MessageBox.Show("Введите корректные данные!");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Что-то пошло не так");
            }
        }

        private void EventsBT_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new Pages.EventsPage());
        }
    }
}
