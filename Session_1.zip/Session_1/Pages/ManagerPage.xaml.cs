﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace Session_1.Pages
{
    /// <summary>
    /// Логика взаимодействия для ManagerPage.xaml
    /// </summary>
    public partial class ManagerPage : Page
    {
        public ManagerPage()
        {
            InitializeComponent();

            try
            {
                var mr = ModelAccess.CurrentUser.Genders.Gender.ToLower() == "мужской" ? "Mrs" : "Ms";
                mr += " " + ModelAccess.CurrentUser.Name;

                TimeSpan now = new TimeSpan(DateTime.Now.Ticks);

                if (now >= new TimeSpan(9, 0, 0) & now <= new TimeSpan(11, 1, 0))
                    GoodDayTimeLB.Content = "Доброе утро!\n" + mr;
                else if (now < new TimeSpan(18, 1, 0))
                    GoodDayTimeLB.Content = "Добрый день!\n" + mr;
                else
                    GoodDayTimeLB.Content = "Добрый вечер!\n" + mr;
            }

            catch (Exception)
            {
                MessageBox.Show("Что-то пошло не так");
            }
        }

        private void BackBT_Click(object sender, RoutedEventArgs e) => Manager.MainFrame.Navigate(new Pages.LoginPage());

        private void AddBT_Click(object sender, RoutedEventArgs e) => Manager.MainFrame.Navigate(new Pages.AddJudgeModPage());

        private void EventsBT_Click(object sender, RoutedEventArgs e) => Manager.MainFrame.Navigate(new Pages.EventsPage());
    }
}
