﻿using Session_1.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public static class ModelAccess
{
    public static Users CurrentUser;
    private static Entities context;
    public static Entities Context
    {
        get
        {
            if (context == null)
            {
                context = new Entities();
            }
            return context;
        }
    }
}